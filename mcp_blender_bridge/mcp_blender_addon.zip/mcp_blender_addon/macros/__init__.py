"""Colección de macros de Blender.

Cada macro es un módulo con una función pública ``run(**kwargs)``.
"""
